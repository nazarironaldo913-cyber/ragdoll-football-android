RAGDOLL FOOTBALL - ANDROID PROJESİ

Bu klasör, gönderdiğin ragdoll-football.html dosyasını Android uygulaması içine alan bir Android Studio projesidir.

ÖNEMLİ:
- Bu henüz APK dosyası değildir; bu ortamda Android SDK/Gradle derleyicisi bulunmadığı için APK derlemesi yapılamadı.
- Proje Android Studio ile açılıp Build > Build APK(s) seçilerek APK'ya dönüştürülebilir.
- Uygulama yatay ekran, tam ekran ve çevrimdışı çalışacak şekilde ayarlandı.
- Oyunun HTML dosyası app/src/main/assets/index.html içindedir.
- Oyun mekaniği yeniden yazılmadı.

Android Studio:
1. ZIP'i bilgisayara çıkar.
2. Android Studio'da RagdollFootball klasörünü aç.
3. Gradle senkronizasyonunun tamamlanmasını bekle.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) seç.
5. APK, app/build/outputs/apk/debug/ klasöründe oluşur.

Not: İlk açılışta Android Studio, gerekli Gradle/Android bileşenlerini internetten indirebilir.
